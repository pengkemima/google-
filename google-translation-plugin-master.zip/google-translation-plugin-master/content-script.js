const sendMassage = (str) => {
	chrome.runtime.sendMessage(
		{ greeting: str }
	);
};

document.onkeydown = function (e) {
	if (e.keyCode === 17) {
    sendMassage(window.getSelection().toString())
	}
};
