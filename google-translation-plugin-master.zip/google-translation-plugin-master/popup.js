import sha256 from "./js/sha256.js";

var script=document.createElement("script");  
script.type="text/javascript";  
script.src="./js/jquery.js"; 
document.getElementsByTagName('head')[0].appendChild(script);

// 翻译后的文本
let translateContent = document.getElementById("translateContent");
// 翻译前的文本
let chooseStr = document.getElementById("chooseStr");
const translate = (str) => {
	var appKey = "44725bd1f0045a6f";
	var key = "QftDsnvgnCfU3mNJVapKs3loMyk1MC1x"; //注意：暴露appSecret，有被盗用造成损失的风险
	var salt = new Date().getTime();
	var curtime = Math.round(new Date().getTime() / 1000);
	var query = str;
	var from = "auto";
	var to = "auto";
	var str1 = appKey + truncate(query) + salt + curtime + key;
	var vocabId = "您的用户词表ID";

	var sign = sha256(str1)
	$.ajax({
		url: "https://openapi.youdao.com/api",
		type: "post",
		dataType: "jsonp",
		data: {
			q: query,
			appKey: appKey,
			salt: salt,
			from: from,
			to: to,
			sign: sign,
			signType: "v3",
			curtime: curtime,
			vocabId: vocabId,
		},
		success: function (data) {
			translateContent.innerHTML = data.translation[0]
		},
	});

	function truncate(q) {
		var len = q.length;
		if (len <= 20) return q;
		return q.substring(0, 10) + len + q.substring(len - 10, len);
	}
};

chrome.runtime.onMessage.addListener(function (request) {
	chooseStr.innerHTML = request.greeting;
  translate(request.greeting)
});
