chrome.runtime.onInstalled.addListener(function () {
	chrome.declarativeContent.onPageChanged.removeRules(undefined, function () {
		chrome.declarativeContent.onPageChanged.addRules([
			{
				conditions: [
					new chrome.declarativeContent.PageStateMatcher({
						pageUrl: { hostEquals: "www.baidu.com" },
					}),
				],
				actions: [new chrome.declarativeContent.ShowPageAction()],
			},
		]);
	});
});
chrome.contextMenus.create({
	id: "9527",
	contexts: ["selection"],
	title: "翻译：%s", // 显示的文字，除非为“separator”类型否则此参数必需，如果类型为“selection”，可以使用%s显示选定的文本
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
	const query = info.selectionText;
	const url = "https://fanyi.baidu.com/translate?#est/zh/" + query;
	chrome.tabs.create({ url: url });
});
